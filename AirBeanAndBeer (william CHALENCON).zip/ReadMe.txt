Ce projet WEB a été fait par William CHALENCON.

Il a été codé en Javascript, HTML et CSS. 

Les outils utilisés sont node.js, WampServer et VSCode.

Ce site WEB est un site de locations de logement (eg. airbnb).

Celui-ci permet d'acceder à une base de données (base de données fournie), de faire une recherche de location, consulter des avis, réserver une location et laisser un avis.

